%  MARKOVP.PRG

% This is a MATLAB program.  It will implement the estimation and testing
% procedures for a Markov switching parameter model as presented in B. Hansen
% "The likelihood ratio test under non-standard conditions: Testing the
% Markov trend model of GNP."


% written by:

% Bruce E. Hansen
% Department of Economics
% Social Science Building
% University of Wisconsin
% Madison, WI 53706-1393
% bhansen@ssc.wisc.edu
% http://www.ssc.wisc.edu/~bhansen/


% The following parameters need to be specified:

% y  = dependent variable
% x  = independent variables, i.e., constant, lagged y's
% iv = 0  to make innovation variance independent of state
% iv = 1  to make innovation variance depend upon state
% ix = [1;2]    Specifies which components of x will depend upon the state.
%            Here, ix specifies the first and second components of x.
%            For example, if you want the intercept to depend upon the state,
%            and the first column of x is a constant, then set "ix = 1".
%            To have the intercept and the second AR lag depend upon the state,
%            then set "ix = 1|3", if the first column of x is a constant, and
%            the third is the second AR lag.
% iq = 0  leaves q unconstrained
% iq = 1  makes q = 1-p

% gn  = number of gridpoints
% rep = number of internal Monte Carlo replications used for test

% tnull_   = 1  to test the null of one state
% tnull_   = 0  to not conduct this test
% nwband_  = 4  to set Newey-West bandwidth to 4

% gopt_  = 1  to calculate global optimum
% gopt_  = 0  to not calculate global optimum

% Note:  If _gopt = 1  and _tnull = 0, then one needs to specify starting values
%        for the parameters in  "th1".  The order is

% (1) Slope coefficients for x in state 0
% (2) Standard deviation of error in state 0
% (3) Difference in slope coefficients between states
% (4) Difference in standard deviation between states (when relevant)
% (5) p
% (6) q (when relevant).


% If tnull_ = 1, then it is necessary to specify a grid for the parameters which
% depend upon the state, for p, and for q when iq = 0.  The number of gridpoints
% must be the same for all regression parameters, but may be different for p or q.
% These gridpoints go in the matrices

%   "gx", "gp" and "gq"

% where gp and gq are vectors, and gx is gn x k1 matrix, gn being number of
% gridpoints and k1 being number of parameters which depend upon the state.
% That is, each column of gx are the gridpoints for a particular parameter.

% Finally, an appropriate likelihood function must be included.  This likelihood
% function be a function of all of the above listed variables, even when not
% relevant.  The function should return a vector which yields the likelihood
% evaluated at each observation, i.e., an nx1 vector.

% This program is currently set up to reproduce Hansen's results from
% Tables 5 and 6 using "Grid 3"                                            */


%%%%%%%%%%%%%%%%%%%%%%%

function markovp()
global b1;
global p;
global q;
global ss0;
global ss1;
global n;
global x;
global y;
global nar;nar=4;
global k;
global kx;
global ix;
global b1;
global iv;
global iq;
global q;
global p;
out=fopen('markovp.txt','wt');
n=135;
load gnp82.txt;
gnp=gnp82;
tmpgnp=gnp(1,:)';
for ii=2:length(gnp(:,1))
    tmpgnp=[tmpgnp;gnp(ii,:)'];
end;
gnp=100*log(tmpgnp);
clear tmpgnp;
dat=gnp(2:n+1)-gnp(1:n);
nar=4;
y=dat(nar+1:n);
nn = n-nar;
x=ones(nn,1);
j=1;
while j<=nar
    x=[x,dat(nar+1-j:n-j)];
    j=j+1;
end;

iv = 0;
ix = 1;
iq = 0;
tnull_ = 1;
gopt_  = 1;
rep = 1000;
nwband_ = 4;

th=[-.4 .01 -.06 -.25 -.21 .77 1.5 2.2 1.1]';




gn = 20;
gx =(.1:.1:gn*0.1)';   % Note: the columns of gx should equal the rows of ix %

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
k=length(x(1,:));
kx=length(ix(:,1));
k1=kx+iv;
if length(gx(1,:))~=1
    disp(' ');
    disp(' ');
    disp('Columns of matrix  gx  must equal 1\nstate, which are the number of elements in the vector  ix  plus 1 if  iv = 1\n');
    disp(' ');
    disp('Program Terminates');
end;
b1=zeros(k,1);
p=0;
q=0;

pn = 12;
gp = (.1:.075:(pn-1)*.075+.1)';
qn = pn;
gq = gp;

% Calculation Under null %
xxi = inv(x'*x);
b0 = xxi*(x'*y);
u = y - x*b0;
v0 = sqrt((u'*u)/length(u(:,1)));
uu=u*ones(1,length(x(1,:)));
var0=xxi*((x.*uu)'*(x.*uu))*xxi;
se0 = sqrt(diag(var0));
b = [b0;v0];

b1 = zeros(k1,1);
null = clike(b);
mnull = sum(null)';
options = optimset('GradObj','on','LargeScale','on','TolFun',0.0000000000001);
if tnull_ == 1;
    fprintf(out,'The program is now beginning the grid search over the required parameters.\n');
    fprintf(out,'Each parameter setting will be printed on the screen as it comes up.\n');
    fprintf(out,'The parameters are printed in this order:\n');
    fprintf(out,'P, Q, Slope Parameters\n\n');
    fprintf(out,'This may take a while, depending upon your computer and the grid you have selected.\n\n');
    
    gnn = gn^k1;
    cnum = pn*gnn;
    if iq == 0;
        cnum = cnum*qn;
    end;
    ny=length(y(:,1));
    e=normrnd(0,1,ny+nwband_,rep);
    draws=ones(1+nwband_,rep)*(-1000);
    c=zeros(cnum,1);
    cs=c;
    if gopt_==1
        beta=zeros(k+3+k1-iq,cnum);
    end;
    j=0;
    
    i1=1;
    while i1<=length(gp(:,1))
        i1
        p=gp(i1);
        i2=1;
        while i2<=length(gq(:,1))
            if iq==1;
                q=1-p;
                i2=length(gq(:,1));
            else
                q=gq(i2);
            end;
            
            bs=b;
            bi=ones(k1,1);
            
            while max(bi)<=gn
          
                b1=diag(gx(bi,:));
                j=j+1;
                warning off;
                [bnew,f]= fminunc(@mclike,bs,options);
                warning on;
                if gopt_==1
                    beta(1:k+1,j) = bnew;
                    beta(k+2:k+1+k1,j) = b1;
                    beta(k+2+k1,j) = p;
                    if iq==0
                        beta(k+3+k1,j)=q;
                    end;
                end;
                diff = null - clike(bnew);
                diff = diff - mean(diff)';
                se = sqrt(diff'*diff);
                diff = (diff'/se')';
                c(j) = mnull - f;
                cs(j) = ((mnull-f)'/se')';
                diffe = zeros(1,rep);
                nw=0;
                while nw<=nwband_
                    diffe=diffe+diff'*e(1+nw:ny+nw,:);
                    draws(1+nw,:)=max([draws(1+nw,:);(diffe./sqrt(1+nw))]);
                    nw=nw+1;
                end;
                
                bs=bnew;
                bi(k1)=bi(k1)+1;
                if bi(k1)>gn
                    bs=b;
                    if min(bi)<gn
                        while max(bi)>gn
                            [temp,ji]=max(bi);
                            bi(ji)=1;
                            bi(ji-1)=bi(ji-1)+1;
                        end;
                    end;
                end;
            end;
            i2=i2+1;
        end;
        i1=i1+1;
    end;
    [m,mc]=max(cs);
    
    draws=draws';
    pvalue=mean(draws>m);
    
    i=0;
    while i<=nwband_
        draws(:,i+1) = sortrows(draws(:,i+1),1);
        i=i+1;
    end;
    cr=[.8 .9 .95 .99];
    cu=draws(round(cr*rep),:);
    
end;

if gopt_==1
    if tnull_==1
        [temp,maxic]=max(c);
        th=beta(:,maxic);
        th(length(th(:,1))-1+iq)=log(p/(1-p));
        if iq==0
            q=th(length(th(:,1)));
            th(length(th(:,1)))=log(q/(1-q));
        end;
    end;
    
    [bnew,f,exitflag,output,grd,hes]=fminunc(@mglike,th);
    lr=sum(null)'-f;
    r=length(bnew(:,1));
    tiny=0.00001;
    nf=glike(bnew);
    g=zeros(length(nf),length(bnew));
    for ii=1:length(bnew)
        bt=bnew;
        btt=bnew;
        bt(ii)=bnew(ii)+tiny;
        btt(ii)=bnew(ii)-tiny;
        g(:,ii)=((glike(bt)-glike(btt))/(2*tiny))';
    end;

    s=g'*g;
    h=pinv(hes);
    v=h*s*h;
    
    if iq==1
        p=bnew(r);
        p=exp(p)/(1+exp(p));
        bopt=[bnew(1:r-1);p];
        v(r,r)=v(r,r)*((p*(1-p))^2);
    else
        p = bnew(r-1);
        q = bnew(r);
        p = exp(p)/(1+exp(p));
        q = exp(q)/(1+exp(q));
        bopt = [bnew(1:r-2);p;q];
        vt = [(p*(1-p));(q*(1-q))];
        v([r-1 r],[r-1 r]) = (vt*ones(1,2)).*v([r-1 r],[r-1 r]).*(ones(2,1)*(vt'));
    end;
    
    se=sqrt(diag(v));
    g=cumsum(g);
    stable=sum(diag(g'*g/s))/length(g(:,1));
    
end;

fprintf(out,'Log Likelihood: %f\n\n', sum(null));
if gopt_==1;
    fprintf(out,'Results from estimation and testing of Markov switching model.\n\n');
    fprintf(out,'Estimates and standard errors\n\n');
    fprintf(out,'Regression Parameters in State 0\n');
    for ii=1:k
        fprintf(out,'%f   %f\n',bopt(ii),se(ii));
    end;
    fprintf(out,'Standard deviation in State 0\n');
    fprintf(out,'%f   %f\n\n',bopt(k+1),se(k+1));
    fprintf(out,'Differences in regression Parameters in State 1\n');
    for ii=k+2:k+kx+1
        fprintf(out,'%f   %f\n',bopt(ii),se(ii));
    end;
    if iv==1
        fprintf(out,'Standard deviation in State 1\n');
        fprintf(out,'%f   %f\n',bopt(k+kx+2),se(k+kx+2));
    end;
    fprintf(out,'P\n');
    r=length(bopt);
    fprintf(out,'%f   %f\n',bopt(r-1+iq),se(r-1+iq));
    if iq==0
        fprintf(out,'Q\n');
        fprintf(out,'%f   %f\n',bopt(r),se(r));
    end;
    fprintf(out,'\n\n');
    fprintf(out,'Likelihood Value %f\n',f);
    fprintf(out,'Likelihood Ratio %f\n',lr);
    fprintf(out,'2*Likelihood Ratio %f\n',2*lr);
    fprintf(out,'Nyblom Stability %f\n\n\n',stable);
end;
if tnull_==1
    fprintf(out,'Test of Null of One-State Model\n\n');
    fprintf(out,'Grid for p\n');
    for ii=1:length(pn)
        fprintf(out,'%f   ',pn(ii));
    end;
    fprintf(out,'\n');
    if iq==0
        fprintf(out,'Grid for Q\n');
        for ii=1:length(qn)
            fprintf(out,'%f   \n',qn(ii));
        end;
        fprintf(out,'\n');
    end;
    fprintf(out,'Grid for regression Parameters\n');
    for ii=1:length(gx)
        fprintf(out,'%f   ',gx(ii));
    end;
    fprintf(out,'\n\n');
    fprintf(out,'Internal Monte Carlo Replications %f\n',rep);
    fprintf(out,'Standardized LR Test %f\n',m);
    fprintf(out,'p_values\n');
    for ii=1:nwband_+1
        fprintf(out,'%u   %f\n',ii-1,pvalue(ii));
    end;
    fprintf(out,'Upper Criticals\n');
    cru=[(1-cr);(cu')];
    for ii=1:length(cru(:,1))
        for jj=1:length(cru(1,:))
            fprintf(out,'%f   ',cru(ii,jj));
        end;
        fprintf(out,'\n');
    end;   
    fprintf(out,'\n');
    if gopt_==1
        th=beta(:,mc);
        fprintf(out,'Standardized LR maximized at\n');
        fprintf(out,'Regression Parameters\n');
        for ii=k+2:k+1+k1
            fprintf(out,'%f\n',th(ii));
        end;
        fprintf(out,'\n P,Q \n');
        for ii=k+2+k1:k+3+k1-iq
            fprintf(out,'%f\n',th(ii));
        end;
    end;
end;
        
        


        
    
        
        
                       
                
                

function nf=marklike(th)
global k;
global y;
global x;
c = sqrt(2*pi);
sig0 = abs(th(k+1));
sig1 = sig0 + abs(th(2*k+2));
p = th(2*k+3);
q1 = 1 - th(2*k+4);
pp = q1/(1-p+q1);

z = y - x*th(1:k);
qq0 = exp(-(z.^2)./(2*sig0*sig0))./(sig0*c);

z = z - x*th(k+2:2*k+1);
qq1 = exp(-(z.^2)./(2*sig1*sig1))./(sig1*c);
clear z;

n=length(y(:,1));
fit=zeros(n,1);
it=1;
while it<=n
    p1 = q1 + (p - q1)*pp;
    f1 = qq1(it)*p1;
    ff = f1 + qq0(it)*(1-p1);
    pp = f1/ff;
    fit(it) = ff;
    it = it+1;
end;

if min(fit)>0
    f=log(fit);
else
    f=-1000;
end;
nf=-f;

function nfit=dmclike(th)
global b1;
global p;
global q;
global ss0;
global ss1;
global n;
global x;
global y;
global nar;
global k;
global kx;
global ix;
global b1;
global iv;
global iq;
global q;
global p;

c = sqrt(2*pi);

beta1 = th(1:k);
sig0 = abs(th(k+1));
sig1 = sig0;
if iv==1;
    sig1 = sig1 + abs(b1(k1));
end;
beta2 = zeros(k,1);
beta2(ix) = b1(1:kx);
sig02 = sig0.^2;
sig12 = sig1.^2;
qs = 1 - q;

pp = qs/(1-p+qs);

z = y - x*beta1;
z2 = z.^2;
qq0 = exp(-z2./(2*sig02))./(sig0*c);
dqq0 = [(z*ones(1,length(x(1,:))).*x),(z2./sig0 - sig0)];
dqq0 = dqq0.*((qq0./sig02)*ones(1,length(dqq0(1,:))));

z = z - x*beta2;
z2 = z.^2;
qq1 = exp(-z2./(2*sig12))./(sig1*c);
dqq1 = [(z*ones(1,length(x(1,:))).*x),(z2./sig1 - sig1)];
dqq1 = dqq1.*((qq1./sig12)*ones(1,length(dqq0(1,:))));

n = length(y(:,1));
fit = zeros(1,1+k);
dpp = zeros(1,1+k);

it = 1;
while it<=n
    p1 = qs + (p - qs)*pp;
    f1 = qq1(it)*p1;
    ff = f1 + qq0(it)*(1-p1);
    pp = f1/ff;

    dp1 = (p-qs).*dpp;
    df1 = dqq1(it,:).*p1 + qq1(it).*dp1;
    dff = (df1 + dqq0(it,:).*(1-p1) - qq0(it).*dp1)./ff;
    dpp = (df1 - f1.*dff)./ff;
    fit = fit + dff;

    it = it+1;
end
nfit=-fit;
  
function lik=clike(th);
global k;
global ix;
global kx;
global b1;
global iv;
global iq;
global q;
global p;
th2 = zeros(k+1,1);
th2(ix) = b1(1:kx);
if iv == 1; th2(k+1) = b1(k1);  end;
if iq == 1; qs = 1-p; else; qs = q;  end;
ths = [th;th2;p;qs];
lik = marklike(ths);


function [lik,gr]=mclike(th);
lik=sum(clike(th))';
gr=dmclike(th);

function lik=glike(th)
global k;
global kx;
global ix;
global iq;
th1 = th(1:k+1);
th2 = zeros(k+1,1);
th2(ix) = th(k+2:k+1+kx);
r = length(th(:,1));
if iq==1
    p = th(r);
    p = exp(p)/(1+exp(p));
    q = 1-p;
else
    p = th(r-1);
    q = th(r);
    p = exp(p)/(1+exp(p));
    q = exp(q)/(1+exp(q));
end;
th3 = [th1;th2;p;q];
lik = marklike(th3);

function lik=mglike(th)
lik=sum(glike(th));

    

