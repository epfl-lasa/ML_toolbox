%  MARKOVM.M

% This is a Matlab program.  It will implement the estimation and testing
% procedures for the Markov switching mean AR(p) model of Hamilton (1989)
% as presented in B. Hansen "The likelihood ratio test under non-standard
% conditions: Testing the Markov trend model of GNP."

% Written November, 1991
% Modified May,  1994

% written by:

% Bruce E. Hansen
% Department of Economics
% Social Science Building
% University of Wisconsin
% Madison, WI 53706-1393
% bhansen@ssc.wisc.edu
% http://www.ssc.wisc.edu/~bhansen/


% The following parameters need to be specified:

% dat = data
% nar = 4            sets number of autoregressive lags

% gn = number of gridpoints

% tnull_ = 1  to test the null of one state
% tnull_ = 0  to not conduct this test
% nwband_ = 5   (e.g.) Sets the (Newey-West) maximal covariance bandwidth to 5

% gopt_  = 1  to calculate global optimum
% gopt_  = 0  to not calculate global optimum


% Note:  If _gopt = 1  and _tnull = 0, then one needs to specify starting values
%       for the parameters in  "th".  The order is

% (1) Mean in state 0
% (2) AR coefficients
% (3) Standard deviation of error in state 0
% (4) Difference in mean between states
% (5) p
% (6) q


% If _tnull = 1, then it is necessary to specify a grid for the differences in
% the mean between states, for p, and for q.
% These gridpoints go in the matrices.

%  "gx", "gp" and "gq"

% where gp and gq are vectors, and gx is gn x 1 matrix, gn being number of
% gridpoints.

% Finally, an appropriate likelihood function must be included.  This likelihood
% function be a function of all of the above listed variables, even when not
% relevant.  The function should return a vector which yields the likelihood
% evaluated at each observation, i.e., an nx1 vector.

% This program is currently set to reproduce the results from Hansen's paper
% using his "Grid 3".                                                       */


% * ***********************************%
function markovm()
global b1;
global p;
global q;
global ss0;
global ss1;
global n;
global x;
global y;
global nar;nar=4;
out=fopen('markovm.txt','wt');
n=135;
load gnp82.txt;
gnp=gnp82;
tmpgnp=gnp(1,:)';
for ii=2:length(gnp(:,1))
    tmpgnp=[tmpgnp;gnp(ii,:)'];
end;
gnp=100*log(tmpgnp);
clear tmpgnp;
dat=gnp(2:n+1)-gnp(1:n);
tnull_=1;
gopt_=1;
nwband_=5;
options = optimset('GradObj','on','LargeScale','on','TolFun',0.0000000000001);

th=[-.4 .01 -.06 -.25 -.21 .77 1.5 2.2 1.1]';


gn=20;
gx=(.1:.1:.1*gn)';
opmiter_ = 500;
opgtol_ = .0001;

pn=8;
gp=(.12:.11:.12+(pn-1)*.11)';
qn=pn;
gq=gp;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
b1=0;
p=.5;
q=.5;

y=dat(1+nar:n);
if nar>0
    x=dat(nar:n-1);
    it=2;
    while it<=nar
        x=[x,dat(nar-it+1:n-it)];
        it=it+1;
    end;
    z1=[0;1];
    n3=2^(nar-1);
    ss=z1(1)*ones(n3,1);
    for ii=2:length(z1)
        ss=[ss;z1(ii)*ones(n3,1)];
    end;
    
    it=2;
    while it<=nar
        temp=ones(2^(nar-it),1)*z1(1);
        for ii=2:length(z1(:,1))
            temp=[temp;ones(2^(nar-it),1)*z1(ii)];
        end;
        tempp=temp;
        for ii=2:2^(it-1)
            tempp=[tempp;temp];
        end;
        ss=[ss,tempp];
        clear temp;
        clear tempp;
        it=it+1;
    end;
    ss0=ss(1:n3,:);
    ss1=ss(n3+1:n3*2,:);
end;

if length(gx(1,:))~=1
    disp(' ');
    disp(' ');
    disp('Columns of matrix  gx  must equal 1');
    disp(' ');
    disp('Program Terminates');
end;

%  Calculation Under null  %
if nar>0
    xx=[ones(n-nar,1),x];
else
    xx=ones(n-nar,1);
end;
xxi=inv(xx'*xx);
b0=xxi*(xx'*y);
u=y-xx*b0;
v0=sqrt(u'*u/length(u(:,1)));
uu=u*ones(1,length(xx(1,:)));
var0=xxi*((xx.*uu)'*(xx.*uu))*xxi;
se0=sqrt(diag(var0));
if nar>0
    phi=b0(2:1+nar);
    a0=b0(1)/(1-sum(phi));
    b=[a0;phi;v0];
else
    a0=b0(1);
    b=[a0;v0];
end;

b1=0;
null=clike(b);
mglike(th)
fprintf(out,'Null %f\n',sum(null));
if tnull_==1;
    output_=0;
    
    gnn = gn;
    crit = zeros(length(y(:,1)),pn*qn*gnn);
    if gopt_ == 1;
        beta = zeros(5+nar,pn*qn*gnn);
    end;
    j = 0;
    length(gp(:,1))
    i1=1;
    while i1<=length(gp(:,1));
        p=gp(i1);
        i2=1;
        while i2<=length(gq(:,1))
            q=gq(i2);
            bs=b;
            bi=1;
            while max(bi)<=gn
                b1=diag(gx(bi,:));
                j=j+1;
                warning off;
                [bnew,f]= fminunc(@mclike,bs,options);
                %p~q~b1~_opitdta[1]~tm;
                warning on;
                if gopt_==1
                    beta(1:2+nar,j) = bnew;
                    beta(3+nar:3+nar,j) = b1;
                    beta(4+nar,j) = p;
                    beta(5+nar,j) = q;
                end;
                crit(:,j)=null - clike(bnew);
                bs=bnew;
                bi(1)=bi(1)+1;
                if bi(1)>gn
                    bs=b;
                    if min(bi)<gn
                        while max(bi)>gn
                            [temp,ji]=max(bi);
                            bi(ji)=1;
                            bi(ji-1)=bi(ji-1)+1;
                        end;
                    end;
                end;
            end;
            i1
            i2
            i2=i2+1;
        end;
        i1=i1+1;
    end;
    
    c=sum(crit)';
    nr=length(crit(:,1));
    crit=crit-ones(length(crit(:,1)),1)*(c'/nr);
    se=sqrt(sum(crit.^2)');
    crit=crit./(ones(length(crit(:,1)),1)*se');
    cse=c./se;
    [m,mc]=max(cse);
    
    rep=1000;
    u=zeros(rep,nwband_+1);
    i1=1;
    while i1<=rep
        e=normrnd(0,1,nr+nwband_,1);
        ee=e(1:nr)*ones(1,nwband_+1);
        i2=1;
        while i2<=nwband_
            ee(:,i2+1:nwband_+1)=ee(:,i2+1:nwband_+1)+ e(1+i2:nr+i2)*ones(1,nwband_-i2+1);
            i2=i2+1;
        end;
        ee=ee./(ones(length(ee(:,1)),1)*sqrt((1:nwband_+1)));
        u(i1,:)=max(crit'*ee);
        i1=i1+1;
    end;
    
    pvalue=mean(u>m)';
    i=1;
    while i<=nwband_+1;
        u(:,i)=sortrows(u(:,i),1);
        i=i+1;
    end;
    cr=[.8 .9 .95 .99];
    cu=u(round(cr*rep),:);

end;
if gopt_==1
    if tnull_==1
        [temp,maxic]=max(c);
        th=beta(:,maxic);
        p=th(4+nar);
        th(4+nar)=log(p/(1-p));
        q=th(5+nar);
        th(5+nar)=log(q/(1-q));
    end;

    [bnew,f,exitflag,output,grd,hes]=fminunc(@mglike,th);
    lr=sum(null)'-f;

    tiny=0.00001;
    nf=glike(bnew);
    g=zeros(length(nf),length(bnew));
    for ii=1:length(bnew)
        bt=bnew;
        btt=bnew;
        bt(ii)=bnew(ii)+tiny;
        btt(ii)=bnew(ii)-tiny;
        g(:,ii)=((glike(bt)-glike(btt))/(2*tiny))';
    end;

    s=g'*g;
    h=pinv(hes);
    v=h*s*h;

    p=bnew(4+nar);
    q=bnew(5+nar);
    p=exp(p)/(1+exp(p));
    q=exp(q)/(1+exp(q));
    bopt=[bnew(1:3+nar);p;q];
    vt=[(p*(1-p));(q*(1-q))];
    v([4+nar 5+nar],[3+nar 4+nar])=(vt*ones(1,2)).*v([4+nar 5+nar],[3+nar 4+nar]).*(ones(2,1)*vt');

    se=sqrt(diag(v));
    g=cumsum(g);
    stable=sum(diag((g'*g)/s))/length(g(:,1));
end;

fprintf(out,'Estimation Under Null of Linearity\n');
fprintf(out,'Regression Parameters:\n');
for ii=1:length(b0)
    fprintf(out,'%f   %f\n',b0(ii),se0(ii));
end;
fprintf(out,'\n Standard Deviation :%f \n\n',v0);
fprintf(out,'Log Likelihood: %f\n\n', sum(null));
if gopt_==1;
    fprintf(out,'Results from estimation and testing of Markov switching model.\n\n');
    fprintf(out,'Estimates and standard errors\n\n');
    fprintf(out,'Regression Parameters in State 0\n');
    for ii=1:1+nar
        fprintf(out,'%f   %f\n',bopt(ii),se(ii));
    end;
    
    fprintf(out,'Stand Deviation\n %f   %f\n',bopt(2+nar),se(2+nar));
    fprintf(out,'\n Difference in mean between states');
    fprintf(out,'%f   %f\n P \n',bopt(3+nar),se(3+nar));
    fprintf(out,'%f   %f\n Q \n',bopt(4+nar),se(4+nar));
    fprintf(out,'%f   %f\n\n\n',bopt(5+nar),se(5+nar));
    fprintf(out,'Likelihood Value %f\n',f);
    fprintf(out,'Likelihood Ratio %f\n',lr);
    fprintf(out,'2*Likelihood Ratio %f\n',2*lr);
    fprintf(out,'Nyblom Stability %f\n\n\n',stable);
end;

if tnull_==1
    fprintf(out,'Test of Null of One-State Model\n\n');
    fprintf(out,'Grid for p\n');
    for ii=1:length(pn)
        fprintf(out,'%f   ',pn(ii));
    end;
    fprintf(out,'\n');
    fprintf(out,'Grid for Q\n');
    for ii=1:length(qn)
        fprintf(out,'%f   ',qn(ii));
    end;
    fprintf(out,'\n');
    fprintf(out,'Grid for mean\n');
    for ii=1:length(gx)
        fprintf(out,'%f   \n',gx(ii));
    end;
    fprintf(out,'\n');
    fprintf(out,'Internal Monte Carlo Replications %f\n',rep);
    fprintf(out,'Standardized LR Test %f\n',m);
    fprintf(out,'p_values\n');
    for ii=1:nwband_+1
        fprintf(out,'%u   %f\n',ii-1,pvalue(ii));
    end;
    fprintf(out,'Upper Criticals\n');
    cru=[(1-cr);(cu')];
     for ii=1:length(cru(:,1))
        for jj=1:length(cru(1,:))
            fprintf(out,'%f   ',cru(ii,jj));
        end;
        fprintf(out,'\n');
    end;     
    if gopt_==1
        fprintf(out,'Standardized LR Maximized at\n');
        th=beta(:,mc);
        fprintf(out,'Mean,  %f\n',th(3+nar));
        fprintf(out,'P, Q    %f   %f',th(4+nar),th(5+nar));
    end;
end;
fclose(out);

       
function nf=marklike(th);
global nar;
global ss0;
global ss1;
global n;
global y;
global x;
c=sqrt(2*pi);
alpha0=th(1);
sig0=th(2+nar);
alpha1=th(3+nar);
p=th(4+nar);
q=th(5+nar);
rho=(1-q)/(2-p-q);

if nar>0
    phi=th(2:1+nar);
    b8=alpha0*(1-sum(phi)');
    sphi0=ss0*phi*alpha1;
    sphi1=ss1*phi*alpha1;
else
    b8=alpha0;
end;
pp=[(1-rho);rho];
pxa=[q;(1-p)];
pxb=1-pxa;

it=2;
while it<=nar
    nr=ones(2^(it-2),1);
    tempa=nr*pxa(1);
    tempb=nr*pxb(1);
    for ii=2:length(pxa)
        tempa=[tempa;nr*pxa(ii)];
        tempb=[tempb;nr*pxb(ii)];
    end;  
    pp=[pp.*tempa;pp.*tempb];
    it=it+1;
end;
clear tempa;
clear tempb;
nr=length(pp(:,1))/2;
p0=pp(1:nr);
p1=pp(nr+1:2*nr);

fit=zeros(n-nar,1);

it=1;
while it<=n-nar
    z=y(it)-b8;
    if nar>0
        z=z-x(it,:)*phi;
        z0=z+sphi0;
        z1=z+sphi1;
    else
        z0=z;
        z1=z;
    end;
    
    f00 = exp(-(z0.^2)/(2*sig0*sig0))./(sig0*c);
    f01 = exp(-(z1.^2)/(2*sig0*sig0))./(sig0*c);

    f10 = exp(-((z0-alpha1).^2)/(2*sig0*sig0))./(sig0*c);
    f11 = exp(-((z1-alpha1).^2)/(2*sig0*sig0))./(sig0*c);

    q00 = (f00.*p0)*q;
    q01 = (f01.*p1)*(1-p);

    q10 = (f10.*p0)*(1-q);
    q11 = (f11.*p1)*p;
    
    if nar>1
        s1 = (1:2:(length(p0(:,1))/2-1)*2+1)';
        p0 = [(q00(s1) + q00(s1+1));(q01(s1) + q01(s1+1))];
        p1 = [(q10(s1) + q10(s1+1));(q11(s1) + q11(s1+1))];
    else
        p0 = q00 + q01;
        p1 = q10 + q11;
    end;
    ff = sum(p0)' + sum(p1)';
    p0 = p0./ff;
    p1 = p1./ff;
    fit(it) = ff;
    it=it+1;
end;

if min(fit)>0
    f=log(fit);
else
    f=-1000;
end;
       
nf=-f;

function nsg=dmclike(th);
global nar;
global b1;
global p;
global q;
global ss0;
global ss1;
global n;
global x;
global y;
c=sqrt(2*pi);
alpha0=th(1);
sig0=th(2+nar);
sig2=sig0^2;
alpha1=b1;
rho=(1-q)/(2-p-q);

phisc=1;
if nar>0
    phi   = th(2:1+nar);
    sphi0 = ss0*phi*alpha1;
    sphi1 = ss1*phi*alpha1;
    phisc = 1 - sum(phi)';
end;
b8 = alpha0*phisc;

pp=[(1-rho);rho];
pxa=[q;1-p];
pxb=1-pxa;

it=2;
while it<=nar
    nr=ones(2^(it-2),1);
    pxanr=nr*pxa(1);
    pxbnr=nr*pxb(1);
    for ii=2:length(pxa)
        pxanr=[pxanr;nr*pxa(ii)];
        pxbnr=[pxbnr;nr*pxb(ii)];
    end;
    pp=[(pp.*pxanr);pp.*pxbnr];
    it=it+1;
end;

nr=length(pp(:,1))/2;
p0=pp(1:nr);
p1=pp(nr+1:2*nr);

dp0 = zeros(nr,2+nar);
dp1 = zeros(nr,2+nar);

grdf=zeros(n-nar,2+nar);
it=1;
while it<=n-nar
    z=y(it)-b8;
    if nar>0
        xit = x(it,:);
        z = z - xit*phi;
        z0 = z + sphi0;
        z1 = z + sphi1;
    else;
        z0 = z;
        z1 = z;
    end;
    z10 = z0 - alpha1;
    z11 = z1 - alpha1;
    z02 = z0.^2;
    z12 = z1.^2;
    z102 = z10.^2;
    z112 = z11.^2;
    
    f00 = exp(-z02/(2*sig2))./(sig0*c);
    f01 = exp(-z12/(2*sig2))./(sig0*c);
    f10 = exp(-z102/(2*sig2))./(sig0*c);
    f11 = exp(-z112/(2*sig2))./(sig0*c);
        
    %  These should be the derivatives of ln f(y|S)  %
    %  With respect to alpha0 : %
    dfa00 =  z0.*phisc./sig2;
    dfa01 =  z1.*phisc./sig2;
    dfa10 = z10.*phisc./sig2;
    dfa11 = z11.*phisc./sig2;
    %  With resepct to phi : %
    if nar > 0;
        xit0 = ones(length(ss0(:,1)),1)*xit - ss0.*alpha1 - alpha0;
        xit1 = ones(length(ss1(:,1)),1)*xit - ss1.*alpha1 - alpha0;
        dfp00 = (z0*ones(1,length(xit0(1,:)))).*xit0./sig2;
        dfp01 = (z1*ones(1,length(xit1(1,:)))).*xit1./sig2;
        dfp10 = (z10*ones(1,length(xit0(1,:)))).*xit0./sig2;
        dfp11 = (z11*ones(1,length(xit1(1,:)))).*xit1./sig2;
    end;
    % With resepct to sig0 : %
    dfs00 = z02./(sig0*sig2) - 1/sig0;
    dfs01 = z12./(sig0*sig2) - 1/sig0;
    dfs10 = z102./(sig0*sig2) - 1/sig0;
    dfs11 = z112./(sig0*sig2) - 1/sig0;
    
    if nar>0
        df00 = [dfa00,dfp00,dfs00];
        df01 = [dfa01,dfp01,dfs01];
        df10 = [dfa10,dfp10,dfs10];
        df11 = [dfa11,dfp11,dfs11];
    else;
        df00 = [dfa00,dfs00];
        df01 = [dfa01,dfs01];
        df10 = [dfa10,dfs10];
        df11 = [dfa11,dfs11];
    end;
    
    q00 = (f00.*p0)*q;
    q01 = (f01.*p1)*(1-p);
    q10 = (f10.*p0)*(1-q);
    q11 = (f11.*p1)*p;
    
    if nar > 1;
        s1 = (1:2:(length(p0(:,1))/2-1)*2+1)';
        p0 = [(q00(s1) + q00(s1+1));(q01(s1) + q01(s1+1))];
        p1 = [(q10(s1) + q10(s1+1));(q11(s1) + q11(s1+1))];
    else;
        p0 = q00 + q01;
        p1 = q10 + q11;
    end;
    ff = sum(p0)' + sum(p1)';
    p0 = p0./ff;
    p1 = p1./ff;
  
    temp=dp0 + df00;
    dq00 = (q00*ones(1,length(temp(1,:)))).*(temp);
    temp=dp1 + df01;
    dq01 = (q01*ones(1,length(temp(1,:)))).*(temp);
    temp=dp0 + df10;
    dq10 = (q10*ones(1,length(temp(1,:)))).*(temp);
    temp=dp1 + df11;
    dq11 = (q11*ones(1,length(temp(1,:)))).*(temp);
    
    df = sum(dq00)' + sum(dq01)' + sum(dq10)' + sum(dq11)';
    dlnf = (df'/ff')';
    grdf(it,:) = dlnf';
    
    if nar > 1;
        s1 = (1:2:(length(p0(:,1))/2-1)*2+1);
        dp0 =[(dq00(s1,:) + dq00(s1+1,:));(dq01(s1,:) + dq01(s1+1,:))];
        dp1 =[(dq10(s1,:) + dq10(s1+1,:));(dq11(s1,:) + dq11(s1+1,:))];
    else;
        dp0 = dq00 + dq01;
        dp1 = dq10 + dq11;
    end;
    dp0 = dp0./(p0.*ff*ones(1,length(dp0(1,:)))) - ones(length(dp0(:,1)),1)*dlnf';
    dp1 = dp1./(p1.*ff*ones(1,length(dp1(1,:)))) - ones(length(dp1(:,1)),1)*dlnf';
    
    it=it+1;
end
nsg=-sum(grdf);

function mths=clike(th);
global b1;
global p;
global q;
ths=[th;b1;p;q];
mths=marklike(ths);

function [lik,gr]=mclike(th);
lik=sum(clike(th))';
gr=dmclike(th);

function lik=glike(th);
global nar;
p = th(4+nar);
q = th(5+nar);
p = exp(p)/(1+exp(p));
q = exp(q)/(1+exp(q));
th2 = [th(1:3+nar);p;q];
lik = marklike(th2);

function lik=mglike(th)
lik=sum(glike(th))';




    
    
    
    
        

    
    
    
    
    


