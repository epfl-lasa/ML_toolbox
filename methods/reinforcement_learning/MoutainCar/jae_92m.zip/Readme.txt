There 4 files in this directory
Data file:
  GNP82.TXT
M files:
  MARKOVM.M
  MARKOVP.M
and
  Readme.txt.

Make sure they are in the working directory of Matlab. The results will be stored in TXT files.